public class RemoveTens {
    	public static void main(String[] args) 
	{
        	int[] arr = {1,99,10};
		int j;
		int cnt=0;
        	System.out.println("Original Array: ");
        	for (int element : arr) {
            	System.out.print(element + " ");
        	}
        	System.out.println();
		int n = arr.length;
		for(int i=0;i<n;i++)
		{
			if(arr[i]==10)
			{
				arr[i]=0;
			}
		}
		int[] arr1=new int[arr.length];
		j=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]!=0){
				arr1[j]=arr[i];
				j++;
			}
		}
		for(int i=0;i<arr1.length;i++)
			System.out.print(arr1[i]+" ");
		System.out.println();	
	}
}