public class ArrangeEvenOdd {
    	public static void main(String[] args) 
	{
        	int[] arr = {1,0,1,0,0,1,1};
		int[] arr1=new int[arr.length];
		int j;
        	System.out.println("Original Array: ");
        	for (int element : arr) {
            	System.out.print(element + " ");
        	}
        	System.out.println();
		int n = arr.length;
		j=0;
		for(int i=0;i<n;i++)
		{
			if(arr[i]%2==0)
				arr1[j++]=arr[i];
		}
		for(int i=0;i<n;i++)
		{
			if(arr[i]%2!=0)
				arr1[j++]=arr[i];
		}
		for(int ele:arr1)
			System.out.print(ele+" ");
		System.out.println();
	}
}