public class TwoDReverse {
    	public static void main(String[] args) 
	{
		if(args.length!=4)
		{
			System.out.println("Please provide 4 integers");
		}
		else
		{
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[1]);
		int num3=Integer.parseInt(args[2]);
		int num4=Integer.parseInt(args[3]);
        	int[][] a={{num1,num2},{num3,num4}};
		System.out.println("Original Array:");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
				System.out.print(a[i][j]+" ");
			System.out.println();
		}
		System.out.println("Reversed Array:");
		for(int i=1;i>=0;i--)
		{
			for(int j=1;j>=0;j--)
				System.out.print(a[i][j]+" ");
			System.out.println();
		}
		}
	}
}