public class SumOfElements {
    	public static void main(String[] args) 
	{
        	int[] arr = {7,1,2,3,6};
		int sum=0;
		int j;
        	System.out.println("Original Array: ");
        	for (int element : arr) {
            	System.out.print(element + " ");
        	}
        	System.out.println();
		int n = arr.length;
		for(int i=0;i<n;i++)
		{
			if(arr[i]==6)
			{
			j=i;
				while(j<n)
				{
					if(arr[j]==7)
					{
						i=j+1;
						break;
					}
				j++;
				}
			}
		sum=sum+arr[i];
		}	
		System.out.println(sum);
	}
}