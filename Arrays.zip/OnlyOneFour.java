public class OnlyOneFour {
    	public static void main(String[] args) 
	{
        	int[] arr = {1,4,1,5};
		boolean chk;
		int cnt=0;
		System.out.println("Original Array: ");
        	for (int element : arr) {
            	System.out.print(element + " ");
        	}
        	System.out.println();
		int n = arr.length;
		for(int i=0;i<n;i++)
		{
			if(arr[i]==1 || arr[i]==4)
				cnt++;
		}
		if(cnt==arr.length)
			chk=true;
		else
			chk=false;
	System.out.println(chk);	
	}
}