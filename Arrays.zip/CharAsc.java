class CharAsc
{
	public static void main(String args[])
	{
		char var1='s';
		char var2='e';
		if(var1>var2)
		{
			System.out.println(var2+","+var1);
		}
		else	
		{
			System.out.println(var1+","+var2);
		}
	}
}