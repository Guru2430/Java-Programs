class LargeSmall
{
	public static void main(String[] args)
	{
		int arr[]=new int[]{23,55,11,66,44};
		int temp;
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i]>arr[j])
				{
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}	
		System.out.println("Smallest two numbers are: "+arr[0]+" "+arr[1]);
		System.out.println("Largest two numbers are: "+arr[arr.length-1]+" "+arr[arr.length-2]);
	}
}