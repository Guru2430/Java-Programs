class SumAvg
{
	public static void main(String[] args)
	{
		int arr[]=new int[]{2,4,5,3,6};
		int sum=0;
		double avg;
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		avg=sum/arr.length;
		System.out.println("Sum="+sum);
		System.out.println("Average="+avg);		
	}
}