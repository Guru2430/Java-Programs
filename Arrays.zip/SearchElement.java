class SearchElement
{
	public static void main(String[] args)
	{
		int arr[]=new int[]{1,4,34,56,7};
		int found=0;
		int i;
		int key=90;
		for(i=0;i<arr.length;i++)
		{
			if(arr[i]==key) 
			{
				found=1;
				break;
			}
		}
		if(found==1)
			System.out.println(i);
		else
			System.out.println("-1");		
	}
}