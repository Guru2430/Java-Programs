class AsciiChar
{
	public static void main(String[] args)
	{
		int arr[]=new int[]{67,69,76,73,78};
		char arr1[]=new char[arr.length];
		for(int i=0;i<arr1.length;i++)
		{
			arr1[i]=(char)arr[i];
			System.out.print(arr1[i]+" ");
		}	
	}
}