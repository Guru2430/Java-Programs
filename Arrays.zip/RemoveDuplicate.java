public class RemoveDuplicate {
    public static void main(String[] args) {
        int[] arr = {12,34,12,45,67,89};
        System.out.println("Original Array: ");
        for (int element : arr) {
            System.out.print(element + " ");
        }
        System.out.println();
	int n = arr.length;
	int uniqueCount = 0;
        for (int i = 0; i < n; i++) {
            boolean isDuplicate = false;
            for (int j = 0; j < i; j++) {
                if (arr[i] == arr[j]) {
                    isDuplicate = true;
                    break;
                }
            }
            if (!isDuplicate) {
                uniqueCount++;
            }
            }

	int[] uniqueArray = new int[uniqueCount];
        int index = 0;
	for (int i = 0; i < n; i++) {
            boolean isDuplicate = false;
            for (int j = 0; j < i; j++) {
                if (arr[i] == arr[j]) {
                    isDuplicate = true;
                    break;
                }
            }
            if (!isDuplicate) {
                uniqueArray[index++] = arr[i];
            }
        }
	for (int element : uniqueArray) {
            System.out.print(element + " ");
        }
        System.out.println();
	}
}