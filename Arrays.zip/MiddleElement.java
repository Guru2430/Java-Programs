public class MiddleElement {
    	public static void main(String[] args) 
	{
        	int[] a={1,2,3};
		int[] b={4,5,6};	
		int cnt=0;
		int j=0;
		System.out.println("Original Arrays: ");
        	for (int element : a) {
            	System.out.print(element + " ");
        	}
        	System.out.println();
		for (int element : b) {
            	System.out.print(element + " ");
        	}
        	System.out.println();
		int n1 = a.length;
		int n2=b.length;
		cnt=(n1-2)+(n2-2);
		int[] arr=new int[cnt];
		for(int i=1;i<n1-1;i++)
			arr[j++]=a[i];
		for(int i=1;i<n2-1;i++)
			arr[j++]=b[i];
		for(int ele:arr)
			System.out.print(ele+" ");
		System.out.println();
	}
}