class MaxMin
{
	public static void main(String[] args)
	{
		int arr[]=new int[]{2,4,5,3,6};
		int max=arr[0];
		int min=arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(max>arr[i]) max=arr[i];
			if(min<arr[i]) min=arr[i];
		}
		System.out.println("Maximum elements="+max);
		System.out.println("Minimul elements="+min);		
	}
}