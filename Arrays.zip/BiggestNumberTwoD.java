public class BiggestNumberTwoD {
    	public static void main(String[] args) 
	{
		if(args.length!=9)
		{
			System.out.println("Please provide 9 integers");
		}
		else
		{
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[1]);
		int num3=Integer.parseInt(args[2]);
		int num4=Integer.parseInt(args[3]);
		int num5=Integer.parseInt(args[4]);
		int num6=Integer.parseInt(args[5]);
		int num7=Integer.parseInt(args[6]);
		int num8=Integer.parseInt(args[7]);
		int num9=Integer.parseInt(args[8]);
        	int[][] a={{num1,num2,num3},{num4,num5,num6},{num7,num8,num9}};
		System.out.println("Original Array:");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				System.out.print(a[i][j]+" ");
			System.out.println();
		}
		int max=a[0][0];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(max<a[i][j]) max=a[i][j];
			}
		}
	System.out.println("Maximum element in given array:"+max);	
	}
	}
}