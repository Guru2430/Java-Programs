class stringremovefirstlast
{
	public static void main(String[] args)
	{
		String str1="Wipro Technologies";
		int n=str1.length();
		StringBuffer s1=new StringBuffer(str1);
		s1.deleteCharAt(0);
		n=s1.length();
		s1.deleteCharAt(n-1);	
		System.out.println(s1.toString());
	}
}