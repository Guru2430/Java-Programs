class stringhalf
{
	public static void main(String[] args)
	{
		String str1="TomCat";
		int n=str1.length();
		if(n%2==0)
		{
			System.out.println(str1.substring(0,n/2));
		}
		else
		{
			System.out.println("null");
		}
	}
}