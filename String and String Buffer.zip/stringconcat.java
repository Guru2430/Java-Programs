class stringconcat
{
	public static void main(String[] args)
	{
		String str1="Mark";
		String str2="Kate";
		StringBuffer s1 = new StringBuffer();
		s1.append(str1).append(str2);
        	String str3=s1.toString().toLowerCase();
		for (int i = 0; i < str3.length() - 1; i++) 
		{
            		if (str3.charAt(i) == str3.charAt(i + 1)) 
			{
                		s1.deleteCharAt(i);
                		break;
			} 
		}
		System.out.println(s1.toString());
	}
}