class stringremovestar
{
	public static void main(String[] args)
	{
		String str="abcdf*cdfd";
		String str1="";
		int starIndex = str.indexOf('*');
	        if (starIndex > 0 && starIndex < str.length()-1) 
		{
             		str1=str.substring(0, starIndex-1) + str.substring(starIndex+2);
        	}
		System.out.println(str1);
	}
}