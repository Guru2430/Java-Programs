class stringrepetitionchar
{
	public static void main(String[] args)
	{
		String str="Wipro";
		int n=3;
		int n1=str.length();
		StringBuffer res=new StringBuffer();
		for(int i=0;i<n;i++)
		{
			res.append(str.substring(n1-n));
		}
	System.out.println(res.toString());
	}
}