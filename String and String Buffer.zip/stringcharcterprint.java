class stringcharcterprint
{
	public static void main(String[] args)
	{
		String str="HelloCSE";
		String str1="World";
		StringBuffer result = new StringBuffer();
	        int minLength = Math.min(str.length(), str1.length());
	        for (int i = 0; i < minLength; i++) 
		{
            		result.append(str.charAt(i)).append(str1.charAt(i));
       		 }
		if (str.length() > minLength) {
            		result.append(str.substring(minLength));
        	}
		else if (str1.length() > minLength) {
            		result.append(str1.substring(minLength));
        	}
	System.out.println(result.toString());
	}
}