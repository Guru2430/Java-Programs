class stringshortlongshort
{
	public static void main(String[] args)
	{
		String a="hello";
		String b="hi";
		String shortstr;
		String longstr;
		if(a.length()>b.length())
		{
			shortstr=b;
			longstr=a;
		}
		else
		{
			shortstr=a;
			longstr=b;
		}
		System.out.println(shortstr+longstr+shortstr);
	}
}