class stringwithoutx
{
	public static void main(String[] args)
	{
		String st1="xhellox";
		int n1=st1.length();
		StringBuffer st11=new StringBuffer(st1);
		char c1=st1.charAt(0);
		char c2=st1.charAt(n1-1);
		if(c1==c2)
		{
			st11.deleteCharAt(0);
			st11.deleteCharAt(n1-2);
			System.out.println(st11.toString());	
		}
		else
		{
			System.out.println(st1);
		}
	}
}