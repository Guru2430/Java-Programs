class stringcopyfirsttwochar
{
	public static void main(String[] args)
	{
		String str1="Wipro";
		int n=str1.length();
		StringBuffer st=new StringBuffer();
		for(int i=0;i<n;i++)
		{
			st.append(str1.charAt(0)).append(str1.charAt(1));
		}
		System.out.println(st.toString());
	}
}